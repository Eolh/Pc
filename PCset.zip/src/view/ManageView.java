package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.ObjectInputValidation;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class ManageView extends JFrame {

	public ManageView() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setSize(1600,900);
		setTitle("ManageView");
		
		//내 윈도우 화면
		Dimension frameSize = this.getSize();
		Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((windowSize.width - frameSize.width)/2,(windowSize.height - frameSize.height)/2);
		
		JPanel myPanel = new MyPnale();
		
		add(myPanel, BorderLayout.CENTER);
				
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ManageView();
	}
	
	//메인 배경 화면
	class MyPnale extends JPanel{
		Image image;
		public MyPnale(){
			image = Toolkit.getDefaultToolkit().createImage("img/mainHud_back.png");
			
		}
		
		public void paint(Graphics g){
			super.paint(g);
			g.drawImage(image, 0, 0, this);
		}
		
		public void update(Graphics g){
			super.update(g);
		}
	}
}
