package test;

public class SeatTestGui {

}
